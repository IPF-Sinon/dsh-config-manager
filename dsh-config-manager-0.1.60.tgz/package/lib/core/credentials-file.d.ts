/** 凭据值所在的顶层块名（DSH 的 .credentials.yaml 就用这个）。 */
export declare const REFS_BLOCK = "refs";
/**
 * 从 `yaml.load()` 的结果里收集「ref → 值」。
 *
 * 顶层字符串项与 `refs:` 块下的字符串项都算凭据；其余嵌套结构忽略。
 */
export declare function collectCredentialRefs(parsed: unknown): Map<string, string>;
/** 从 YAML 原文收集（解不开就算没有凭据，调用方负责把「解不开」当成别的错误）。 */
export declare function collectCredentialRefsFromText(text: string): Map<string, string>;
