import type { MsgFunc } from '../core/messages.ts';
import type { FilesSection, SectionId } from '../schema/types.ts';
import type { ApplyResult, ConfigAdapter, ExportOptions, ExportSection, HostContext, ImportContext, PlanItem, Portability, ValidationResult } from '../core/types.ts';
export declare abstract class FileCollectionAdapter implements ConfigAdapter<FilesSection> {
    abstract readonly id: SectionId;
    abstract readonly displayName: string;
    abstract readonly defaultIncluded: boolean;
    abstract readonly portability: Portability;
    /** 相对 homeDir 的基准目录（与 core/backup.ts FILE_BASES 一致） */
    abstract readonly baseDir: string;
    /**
     * 文件列表的筛选钩子：默认原样返回（skills / agentPresets / agentInstructions /
     * pluginFiles / self 这些分区不筛）。需要按数量挑子集的子类覆写它 —— 目前只有
     * sessions 这么做（「只要最近几个会话」是真机上最常见的诉求）。
     */
    protected selectRels(_ctx: HostContext, rels: string[], _options: ExportOptions): string[];
    export(ctx: HostContext, options: ExportOptions): Promise<ExportSection<FilesSection>>;
    analyzeImport(data: FilesSection, ctx: ImportContext): Promise<PlanItem[]>;
    applyItem(item: PlanItem, ctx: ImportContext): Promise<ApplyResult>;
    validate(data: FilesSection, msg?: MsgFunc): Promise<ValidationResult>;
}
