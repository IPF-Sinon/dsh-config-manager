import type { ExportOptions, HostContext } from '../core/types.ts';
import { FileCollectionAdapter } from './file-collection.ts';
export declare class SessionsAdapter extends FileCollectionAdapter {
    readonly id: 'sessions';
    readonly displayName = "Sessions";
    readonly defaultIncluded = false;
    readonly portability: 'deviceSpecific';
    readonly baseDir = "sessions";
    /**
     * 会话子集筛选：`options.sessions.limit` 缺省 = 今天的行为（分区被选中就全带）。
     *
     * 单位是**会话目录**（两级：`<projectKey>/<会话目录>`）—— 同一会话的新旧日志必须一起走，
     * 只挑一份会让恢复出来的会话缺一半历史；选中后原文件名照旧，不在这里改名。
     * 目录归属从 `sessions` 树的实际列目录结果算（不猜 projectKey）。
     */
    protected selectRels(ctx: HostContext, rels: string[], options: ExportOptions): string[];
}
