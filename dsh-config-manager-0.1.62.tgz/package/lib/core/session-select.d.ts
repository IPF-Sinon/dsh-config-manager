/** 会话日志文件名判据：`session.jsonl.zstd` / `session.v3.jsonl.zstd` / `session.jsonl` 都算。 */
export declare const SESSION_FILE_RE: RegExp;
/** 这个文件名是不是会话日志（不是的话就是 session.lock 之类的运行时文件）。 */
export declare function isSessionFile(name: string): boolean;
/** 会话树里一个会话目录（两级：`<sessions-root>/<projectKey>/<sessionDir>`）。 */
export interface SessionEntry {
    /** 会话目录名（id 的目录名编码）。 */
    dir: string;
    /** 所属 projectKey 目录名。 */
    project: string;
    /** 会话目录的绝对路径。 */
    path: string;
    /** 该目录下的日志文件绝对路径（至少一个，否则这个目录不算会话）。 */
    files: string[];
    /** 该会话最新一份日志的 mtime（排序依据）。 */
    mtimeMs: number;
}
/** 扫整棵会话树，只返回「真的有会话日志」的会话目录（顺序 = 最新在前）。 */
export declare function listSessions(sessionsRoot: string): SessionEntry[];
/**
 * 按档位挑会话目录。
 *
 * @param limit 0 = 不带会话；负数 = 全带；正数 = 最新 N 个
 */
export declare function pickSessions(sessionsRoot: string, limit: number): SessionEntry[];
/** 会话树里一共有多少个会话（宿主界面显示「最近 N 个 / 共 M 个」用）。 */
export declare function sessionCount(sessionsRoot: string): number;
