/** 改写结果：成功带新内容，失败带原因（调用方据此报 ungrouped，不要抛错）。 */
export type RewriteOutcome = {
    ok: true;
    buffer: Buffer;
    headerLength: number;
    bodyLength: number;
} | {
    ok: false;
    reason: string;
};
/**
 * 算第 1 帧的字节长度。
 *
 * @returns 帧长；不是合法 zstd 帧或越界时返回 null（调用方一律当失败处理）
 */
export declare function firstFrameLength(buf: Buffer): number | null;
/**
 * 逐帧解压整个容器。
 *
 * **必须逐帧**：Node 的 `zstdDecompressSync` 只解**第一个帧**（多帧输入时后面几帧被静默
 * 忽略），所以直接拿它去解会话文件会「只看到 header、以为文件就这一行」。这里按帧头推边界
 * 一帧帧解、拼起来；帧边界不严丝合缝（有尾巴/有残留）就判失败 —— 这类文件宁可不动。
 */
export declare function decompressAllFrames(buf: Buffer): Buffer | null;
/** 解压第 1 帧（只看 header 那一行，不解整个文件）。失败返回 null。 */
export declare function readHeaderLine(buf: Buffer): string | null;
/**
 * 把文件内容里的第 1 帧换成「只含 [headerLine] 的新帧」，其余字节原样接回。
 *
 * headerLine 允许带或不带结尾换行；这里统一补成 `\n`（dsh 侧要求恰好一行 + 换行）。
 * 两重自证（不过就返回失败，绝不返回可疑内容）：
 *   1. 新缓冲区的第 1 帧单独解压后，必须**恰好**是这一行；
 *   2. 新缓冲区整体解压后，必须与旧缓冲区整体解压结果**逐字节相同**。
 */
export declare function rewriteHeader(buf: Buffer, headerLine: string): RewriteOutcome;
