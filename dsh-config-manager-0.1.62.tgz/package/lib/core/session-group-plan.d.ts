/** 已注册工作区的必要信息（registry 里一条记录的子集）。 */
export interface GroupingWorkspace {
    id: string;
    path: string;
}
/** 待归组的会话（rel = 相对 sessions-root 的路径，含文件名）。 */
export interface GroupingSession {
    rel: string;
    id: string;
    cwd: string;
}
export interface GroupingPlanItem {
    id: string;
    rel: string;
    /** group = 只进注册表；rewrite+group = 还要把 header 的 cwd 改写到目标路径 */
    action: 'group' | 'rewrite+group';
    workspace: string;
    how: 'exact' | 'mapped' | 'inferred';
    from: string;
    to: string;
    /** 是否需要改写 header（cwd 规范化后与目标 path 不同） */
    needsRewrite: boolean;
}
export interface GroupingPlanUngrouped {
    rel: string;
    id: string;
    cwd: string;
    reason: string;
}
export interface GroupingPlan {
    items: GroupingPlanItem[];
    ungrouped: GroupingPlanUngrouped[];
}
export interface GroupingPlanInput {
    sessions: GroupingSession[];
    workspaces: GroupingWorkspace[];
    /** cwd → 目标路径（manifest pathMappings 或 --map）。 */
    maps?: Map<string, string>;
    /** 路径规范化（默认 realpathSync；注入只为测试可控）。不存在返回 null。 */
    canonical?: (p: string) => string | null;
}
/**
 * 规划归组。
 *
 * 注意 `pathToId` 用的是**记录里原样的 path**（脚本如此）：会话侧的 cwd 会被规范化后去比，
 * 所以注册表里的 path 必须是已经规范化的真实路径 —— dsh 写的记录本来就满足这一点。
 */
export declare function planGrouping(input: GroupingPlanInput): GroupingPlan;
