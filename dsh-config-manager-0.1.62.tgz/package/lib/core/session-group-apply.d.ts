import type { GroupingPlanItem } from './session-group-plan.ts';
/** registry 里一条工作区记录（未知键一律保留）。 */
export interface RegistryWorkspaceRecord {
    path: string;
    sessionIds?: string[];
    updatedAt?: string;
    [key: string]: unknown;
}
/** registry（已由调用方从 workspace.json 解析出来）。 */
export interface GroupingRegistry {
    /** id → 记录（原样，含未知键）。 */
    table: Record<string, RegistryWorkspaceRecord>;
}
/** 需要在文件系统上执行的动作：写 [to]（内容 [content]），[removeFrom] 非空则删掉旧文件。 */
export interface GroupingFileAction {
    from: string;
    to: string;
    content: Buffer | null;
    /** to 与 from 解析后不同才删源（同路径不能删） */
    removeFrom: boolean;
}
export interface GroupingReport {
    grouped: number;
    groupedSessions: number;
    rewritten: number;
    moved: number;
    ungrouped: {
        path: string;
        id: string;
        cwd: string;
        reason: string;
    }[];
    inferred: {
        id: string;
        from: string;
        to: string;
        workspace: string;
    }[];
    items: {
        id: string;
        action: string;
        workspace: string;
        how: string;
        from: string;
        to: string;
    }[];
}
export interface ApplyGroupingInput {
    items: GroupingPlanItem[];
    registry: GroupingRegistry;
    /** 读会话文件内容（相对 sessions-root 的路径 → 内容）；读不到返回 null。 */
    readSession: (rel: string) => Buffer | null;
    /** 反查目标工作区的 projectKey 目录名；查不到返回 null。 */
    projectKeyFor: (workspacePath: string) => string | null;
    /** 时间戳来源（默认当前时间），注入只为测试可断言。 */
    now?: () => string;
}
export interface ApplyGroupingResult {
    report: GroupingReport;
    /** 复制后的注册表（调用方负责写回；未变更时与原对象内容等价）。 */
    registry: GroupingRegistry;
    actions: GroupingFileAction[];
}
/**
 * 应用规划：算出新注册表与文件动作。
 *
 * 不写盘、不备份 —— 调用方拿到 actions 与 registry 后自行：备份 → 写文件 → 写注册表 →
 * 读回自检 → 失败回滚。
 */
export declare function applyGroupingPlan(input: ApplyGroupingInput): ApplyGroupingResult;
