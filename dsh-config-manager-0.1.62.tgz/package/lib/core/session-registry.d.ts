/** 一条工作区记录（未知键原样保留）。 */
export interface RawWorkspaceRecord {
    path: string;
    sessionIds: string[];
    updatedAt?: string;
    [key: string]: unknown;
}
/** registry 文档的解析结果（table + state 均为**原文档中的对象引用**，改动即改文档）。 */
export interface RegistryParts {
    doc: unknown;
    table: Record<string, RawWorkspaceRecord>;
    /** 全局状态（workspaceIds / initialized） */
    state: Record<string, unknown>;
}
/** 解析 workspace.json 文本；结构不认识返回 null（调用方一律当「读不出」处理）。 */
export declare function parseRegistry(text: string): RegistryParts | null;
/**
 * 红线校验：返回问题清单（空 = 通过）。
 *
 * 覆盖上游 validateStoredState 的等价判据：workspaceIds 顺序唯一、每条记录都在顺序里、
 * 顺序里的每个 id 都有记录、每条记录的 sessionIds 是字符串数组、path 非空。
 */
export declare function validateRegistry(parts: RegistryParts): string[];
/** 是否有进行中的注册表改动（有就绝不能写）。 */
export declare function hasPendingMutation(parts: RegistryParts): boolean;
